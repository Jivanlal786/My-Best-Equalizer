package com.bcdstudio.soundarea;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.animation.LinearInterpolator;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

import com.example.myequalizer.R;

public class BoostActivity extends AppCompatActivity implements View.OnClickListener {
    private ImageView icLoading_1;
    private ImageView icLoading_2;
    private ImageView icLoading_3;
    private ImageView icLoading_4;
    private boolean isDone = false;
    private boolean isSafeTest = false;
    private ImageView ivBack;
    private ImageView ivBgConnect;
    private ImageView ivCkeckConnectScan;
    private LinearLayout lyBottom;
    private LinearLayout lyCheckComplete;
    private RelativeLayout lyTop;
    Runnable runnable = new Runnable() {
        public void run() {
            BoostActivity.this.ivCkeckConnectScan.animate().rotationBy(360.0f).withEndAction(this).setDuration(2000).setInterpolator(new LinearInterpolator()).start();
        }
    };
    Runnable runnableIc1 = new Runnable() {
        public void run() {
            BoostActivity.this.icLoading_1.setImageResource(R.drawable.ic_loading_complete);
            BoostActivity.this.tvScan_1.setTextColor(BoostActivity.this.getResources().getColor(R.color.white));
            BoostActivity.this.icLoading_2.setVisibility(View.VISIBLE);
            BoostActivity.this.icLoading_2.animate().rotationBy(360.0f).withEndAction(BoostActivity.this.runnableIc2).setDuration(1000).setInterpolator(new LinearInterpolator()).start();
            BoostActivity.this.tvScan_2.setTextColor(BoostActivity.this.getResources().getColor(R.color.white));
        }
    };
    Runnable runnableIc2 = new Runnable() {
        public void run() {
            BoostActivity.this.icLoading_2.setImageResource(R.drawable.ic_loading_complete);
            BoostActivity.this.tvScan_2.setTextColor(BoostActivity.this.getResources().getColor(R.color.white));
            BoostActivity.this.icLoading_3.setVisibility(View.VISIBLE);
            BoostActivity.this.icLoading_3.animate().rotationBy(360.0f).withEndAction(BoostActivity.this.runnableIc3).setDuration(1000).setInterpolator(new LinearInterpolator()).start();
            BoostActivity.this.tvScan_3.setTextColor(BoostActivity.this.getResources().getColor(R.color.white));
        }
    };
    Runnable runnableIc3 = new Runnable() {
        public void run() {
            BoostActivity.this.icLoading_3.setImageResource(R.drawable.ic_loading_complete);
            BoostActivity.this.tvScan_3.setTextColor(BoostActivity.this.getResources().getColor(R.color.white));
            BoostActivity.this.icLoading_4.setVisibility(View.VISIBLE);
            BoostActivity.this.icLoading_4.animate().rotationBy(360.0f).withEndAction(BoostActivity.this.runnableIc4).setDuration(1000).setInterpolator(new LinearInterpolator()).start();
            BoostActivity.this.tvScan_4.setTextColor(BoostActivity.this.getResources().getColor(R.color.white));
        }
    };
    Runnable runnableIc4 = new Runnable() {
        public void run() {
            BoostActivity.this.icLoading_4.setImageResource(R.drawable.ic_loading_complete);
            BoostActivity.this.tvScan_4.setTextColor(BoostActivity.this.getResources().getColor(R.color.white));
            BoostActivity.this.ivBgConnect.setImageResource(R.drawable.radio);
            BoostActivity.this.ivBgConnect.getLayoutParams().height = 110;
            BoostActivity.this.ivBgConnect.getLayoutParams().width = 110;
            BoostActivity.this.isSafeTest = true;
            if (BoostActivity.this.isDone) {
                BoostActivity.this.lyTop.setVisibility(View.GONE);
                BoostActivity.this.lyBottom.setVisibility(View.GONE);
                BoostActivity.this.lyCheckComplete.setVisibility(View.VISIBLE);
                BoostActivity.this.icLoading_4.animate().cancel();
                BoostActivity.this.icLoading_3.animate().cancel();
                BoostActivity.this.icLoading_2.animate().cancel();
                BoostActivity.this.icLoading_1.animate().cancel();
                BoostActivity.this.ivCkeckConnectScan.animate().cancel();
            }
            if (BoostActivity.this.isSafeTest) {
                BoostActivity.this.icLoading_1.setImageResource(R.drawable.ic_loading_ckeck);
                BoostActivity.this.icLoading_1.setVisibility(View.GONE);
                BoostActivity.this.icLoading_2.setImageResource(R.drawable.ic_loading_ckeck);
                BoostActivity.this.icLoading_2.setVisibility(View.GONE);
                BoostActivity.this.icLoading_3.setImageResource(R.drawable.ic_loading_ckeck);
                BoostActivity.this.icLoading_3.setVisibility(View.GONE);
                BoostActivity.this.icLoading_4.setImageResource(R.drawable.ic_loading_ckeck);
                BoostActivity.this.icLoading_4.setVisibility(View.GONE);
                BoostActivity.this.tvScan_1.setText(BoostActivity.this.getString(R.string.ckeck_safe_des_1));
                BoostActivity.this.tvScan_2.setText(BoostActivity.this.getString(R.string.ckeck_safe_des_2));
                BoostActivity.this.tvScan_3.setText(BoostActivity.this.getString(R.string.ckeck_safe_des_3));
                BoostActivity.this.tvScan_4.setText(BoostActivity.this.getString(R.string.ckeck_safe_des_4));
                BoostActivity.this.icLoading_1.setVisibility(View.VISIBLE);
                BoostActivity.this.icLoading_1.animate().rotationBy(360.0f).withEndAction(BoostActivity.this.runnableIc1).setDuration(1000).setInterpolator(new LinearInterpolator()).start();
                BoostActivity.this.isDone = true;
            }
        }
    };
    private TextView tvScan_1;
    private TextView tvScan_2;
    private TextView tvScan_3;
    private TextView tvScan_4;

    @Override
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.activity_boost);

        initView();
        setUpViews();
        ((Button) findViewById(R.id.ok_boost)).setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                Toast.makeText(BoostActivity.this.getApplicationContext(), "Optimization Successful!", Toast.LENGTH_SHORT).show();
                BoostActivity.this.finish();
            }
        });
        this.icLoading_1.setVisibility(View.VISIBLE);
        this.icLoading_1.animate().rotationBy(360.0f).withEndAction(this.runnableIc1).setDuration(1000).setInterpolator(new LinearInterpolator()).start();
        this.tvScan_1.setTextColor(getResources().getColor(R.color.white));
    }

    private void setUpViews() {
        this.ivCkeckConnectScan.animate().rotationBy(360.0f).withEndAction(this.runnable).setDuration(2000).setInterpolator(new LinearInterpolator()).start();
    }

    private void initView() {
        ImageView imageView = (ImageView) findViewById(R.id.check_connect__iv_back);
        this.ivBack = imageView;
        imageView.setOnClickListener(this);
        this.ivBgConnect = (ImageView) findViewById(R.id.ckeck_connect__iv_bg_connect);
        this.ivCkeckConnectScan = (ImageView) findViewById(R.id.ckeck_connect__iv_scan);
        this.icLoading_1 = (ImageView) findViewById(R.id.ckeck_connect__iv_loading_1);
        this.icLoading_2 = (ImageView) findViewById(R.id.ckeck_connect__iv_loading_2);
        this.icLoading_3 = (ImageView) findViewById(R.id.ckeck_connect__iv_loading_3);
        this.icLoading_4 = (ImageView) findViewById(R.id.ckeck_connect__iv_loading_4);
        this.tvScan_1 = (TextView) findViewById(R.id.ckeck_connect__tv_scanning_1);
        this.tvScan_2 = (TextView) findViewById(R.id.ckeck_connect__tv_scanning_2);
        this.tvScan_3 = (TextView) findViewById(R.id.ckeck_connect__tv_scanning_3);
        this.tvScan_4 = (TextView) findViewById(R.id.ckeck_connect__tv_scanning_4);
        this.lyTop = (RelativeLayout) findViewById(R.id.ckeck_connect__ly_top_scan);
        this.lyCheckComplete = (LinearLayout) findViewById(R.id.ckeck_connect__ln_boot_complete);
        this.lyBottom = (LinearLayout) findViewById(R.id.ckeck_connect__ln_bottom_scan);
    }

    @Override // androidx.activity.ComponentActivity
    public void onBackPressed() {
        super.onBackPressed();
        finish();
    }

    public void onClick(View view) {
        if (view.getId() == R.id.check_connect__iv_back) {
            finish();
        }
    }

}
