package com.bcdstudio.soundarea;

import android.app.Dialog;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.webkit.WebView;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

import com.example.myequalizer.R;

public class About extends AppCompatActivity {
    @Override // androidx.activity.ComponentActivity, androidx.core.app.ComponentActivity, androidx.appcompat.app.AppCompatActivity, androidx.fragment.app.FragmentActivity
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.activity_about);
        ((LinearLayout) findViewById(R.id.about_rate)).setOnClickListener(new View.OnClickListener() {
            /* class com.bcdstudio.soundarea.About.AnonymousClass1 */

            public void onClick(View view) {
                String packageName = About.this.getPackageName();
                try {
                    About about = About.this;
                    about.startActivity(new Intent("android.intent.action.VIEW", Uri.parse("market://details?id=" + packageName)));
                } catch (ActivityNotFoundException unused) {
                    About about2 = About.this;
                    about2.startActivity(new Intent("android.intent.action.VIEW", Uri.parse("https://play.google.com/store/apps/details?id=" + packageName)));
                }
            }
        });
        ((LinearLayout) findViewById(R.id.about_share)).setOnClickListener(new View.OnClickListener() {
            /* class com.bcdstudio.soundarea.About.AnonymousClass2 */

            public void onClick(View view) {
                Intent intent = new Intent("android.intent.action.SEND");
                intent.setType("text/plain");
                intent.putExtra("android.intent.extra.SUBJECT", "Best Game Booster");
                intent.putExtra("android.intent.extra.TEXT", "https://play.google.com/store/apps/details?id=com.bcdstudio.soundarea");
                About.this.startActivity(Intent.createChooser(intent, "Share using"));
            }
        });
        ((LinearLayout) findViewById(R.id.about_help)).setOnClickListener(new View.OnClickListener() {
            /* class com.bcdstudio.soundarea.About.AnonymousClass3 */

            public void onClick(View view) {
                Intent intent = new Intent("android.intent.action.SEND");
                intent.putExtra("android.intent.extra.EMAIL", new String[]{"caglarbekyurek@gmail.com"});
                intent.putExtra("android.intent.extra.SUBJECT", "Sound Area");
                intent.putExtra("android.intent.extra.TEXT", "please describe your problem ");
                intent.setType("message/rfc822");
                About.this.startActivity(Intent.createChooser(intent, "Choose an Email client :"));
            }
        });
        ((LinearLayout) findViewById(R.id.about_privacy)).setOnClickListener(new View.OnClickListener() {
            /* class com.bcdstudio.soundarea.About.AnonymousClass4 */

            public void onClick(View view) {
                About.this.getHtml("file:///android_asset/privacypolicy.html", "Privacy Policy");
            }
        });
        ((LinearLayout) findViewById(R.id.logo_ico_authors)).setOnClickListener(new View.OnClickListener() {
            /* class com.bcdstudio.soundarea.About.AnonymousClass5 */

            public void onClick(View view) {
                About.this.getHtml("file:///android_asset/icons.html", "Logo Authors");
            }
        });
        ((LinearLayout) findViewById(R.id.opensource_licenses)).setOnClickListener(new View.OnClickListener() {
            /* class com.bcdstudio.soundarea.About.AnonymousClass6 */

            public void onClick(View view) {
                About.this.getHtml("file:///android_asset/licenses.html", "Open Source Licenses");
            }
        });
        ((ImageView) findViewById(R.id.about_back)).setOnClickListener(new View.OnClickListener() {
            /* class com.bcdstudio.soundarea.About.AnonymousClass7 */

            public void onClick(View view) {
                About.super.onBackPressed();
            }
        });
    }

    @Override // androidx.activity.ComponentActivity
    public void onBackPressed() {
        finish();
    }

    private void getHtml(String str, String str2) {
        final Dialog dialog = new Dialog(this);
        dialog.setContentView(R.layout.dialog_ww);
        dialog.setContentView(R.layout.dialog_ww);
        dialog.setCancelable(true);
        ((TextView) dialog.findViewById(R.id.title_source)).setText(str2);
        ((Button) dialog.findViewById(R.id.close_license)).setOnClickListener(new View.OnClickListener() {
            /* class com.bcdstudio.soundarea.About.AnonymousClass8 */

            public void onClick(View view) {
                dialog.cancel();
            }
        });
        ((WebView) dialog.findViewById(R.id.webView)).loadUrl(str);
        dialog.show();
    }
}
