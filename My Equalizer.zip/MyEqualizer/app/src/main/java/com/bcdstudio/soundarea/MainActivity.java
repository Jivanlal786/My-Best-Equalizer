package com.bcdstudio.soundarea;

import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.media.audiofx.BassBoost;
import android.media.audiofx.Equalizer;
import android.media.audiofx.LoudnessEnhancer;
import android.media.audiofx.Virtualizer;
import android.os.Build;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.Spinner;
import android.widget.SpinnerAdapter;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import com.example.myequalizer.R;
import com.marcinmoskala.arcseekbar.ArcSeekBar;
import com.marcinmoskala.arcseekbar.ProgressListener;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity implements SeekBar.OnSeekBarChangeListener {
    static final int MAX_SLIDERS = 5;
    ImageView about;
    ArcSeekBar bassSlider;
    BassBoost bb = null;
    ImageView booster_sv;
    boolean canEnable;
    boolean canPreset;
    boolean dontcall = false;
    Switch enableBass;
    Switch enableLoud;
    Switch enableVirtual;
    Switch enabled = null;
    Equalizer eq = null;
    ArrayList<String> eqPreset;
    ImageView info;
    ArcSeekBar loudSlider;
    LoudnessEnhancer loudnessEnhancer = null;
    LinearLayout loudnessView;
    int max_level = 100;
    int min_level = 0;
    int num_sliders = 0;
    LinearLayout presetView;
    TextView[] slider_labels = new TextView[5];
    SeekBar[] sliders = new SeekBar[5];
    Spinner spinner;
    int spinnerPos = 0;
    ImageView sv_about;
    TextView tester;
    ArcSeekBar virtualSlider;
    Virtualizer virtualizer = null;

    public void onStopTrackingTouch(SeekBar seekBar) {
    }

    /* access modifiers changed from: protected */
    @Override
    // androidx.activity.ComponentActivity, androidx.core.app.ComponentActivity, androidx.appcompat.app.AppCompatActivity, androidx.fragment.app.FragmentActivity
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.activity_main);
        ImageView imageView = (ImageView) findViewById(R.id.av_booster);
        this.booster_sv = imageView;
        imageView.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                MainActivity.this.startActivity(new Intent(MainActivity.this, BoostActivity.class));
            }
        });
        ImageView imageView2 = (ImageView) findViewById(R.id.av_about);
        this.sv_about = imageView2;
        imageView2.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                MainActivity.this.startActivity(new Intent(MainActivity.this, About.class));
            }
        });
        ImageView imageView3 = (ImageView) findViewById(R.id.av_info);
        this.info = imageView3;
        imageView3.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
                builder.setTitle("Update History");
                builder.setMessage("version 1.0.0 This service has just been released from the beta process. \n\nFor best performance, please do not use any other equalizer. you can specify errors in this version in the comments section\n\nThanks for using ");
                builder.setNegativeButton("Close", (DialogInterface.OnClickListener) null);
                builder.show();
            }
        });
        ImageView imageView4 = (ImageView) findViewById(R.id.about);
        this.about = imageView4;
        imageView4.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
                builder.setTitle("Equalizer");
                builder.setMessage("Don't forget to disable other Equalizer on your hone before enabling it!\n\nSadly We Can Say That It Doesn't Work in Some Custom Roms (LineageOs, Resurrection Remix etc.)");
                builder.setNegativeButton("Close", (DialogInterface.OnClickListener) null);
                builder.show();
            }
        });

        this.tester = (TextView) findViewById(R.id.acik_kapali);
        Switch r6 = (Switch) findViewById(R.id.switchEnable);
        this.enabled = r6;
        r6.setChecked(true);
        this.spinner = (Spinner) findViewById(R.id.spinner);
        this.sliders[0] = (SeekBar) findViewById(R.id.mySeekBar0);
        this.slider_labels[0] = (TextView) findViewById(R.id.centerFreq0);
        this.sliders[1] = (SeekBar) findViewById(R.id.mySeekBar1);
        this.slider_labels[1] = (TextView) findViewById(R.id.centerFreq1);
        this.sliders[2] = (SeekBar) findViewById(R.id.mySeekBar2);
        this.slider_labels[2] = (TextView) findViewById(R.id.centerFreq2);
        this.sliders[3] = (SeekBar) findViewById(R.id.mySeekBar3);
        this.slider_labels[3] = (TextView) findViewById(R.id.centerFreq3);
        this.sliders[4] = (SeekBar) findViewById(R.id.mySeekBar4);
        this.slider_labels[4] = (TextView) findViewById(R.id.centerFreq4);
        this.bassSlider = (ArcSeekBar) findViewById(R.id.bassSeekBar);
        this.virtualSlider = (ArcSeekBar) findViewById(R.id.virtualSeekBar);
        this.enableBass = (Switch) findViewById(R.id.bassSwitch);
        this.enableVirtual = (Switch) findViewById(R.id.virtualSwitch);
        this.enableLoud = (Switch) findViewById(R.id.volSwitch);
        this.loudSlider = (ArcSeekBar) findViewById(R.id.volSeekBar);
        this.presetView = (LinearLayout) findViewById(R.id.presetView);
        this.loudnessView = (LinearLayout) findViewById(R.id.loudnessView);
        this.bassSlider.setMaxProgress(1000);
        this.virtualSlider.setMaxProgress(1000);
        this.loudSlider.setMaxProgress(10000);
        this.enableLoud.setChecked(true);
        this.enableBass.setChecked(true);
        this.enableVirtual.setChecked(true);
        this.eqPreset = new ArrayList<>();
        ArrayAdapter arrayAdapter = new ArrayAdapter(this, 17367048, this.eqPreset);
        arrayAdapter.setDropDownViewResource(17367049);
        this.eq = new Equalizer(100, 0);
        this.bb = new BassBoost(100, 0);
        this.virtualizer = new Virtualizer(100, 0);
        if (Build.VERSION.SDK_INT >= 19) {
            this.loudnessEnhancer = new LoudnessEnhancer(0);
        } else {
            this.enableLoud.setChecked(false);
            this.loudnessView.setVisibility(View.GONE);
        }
        Equalizer equalizer = this.eq;
        if (equalizer != null) {
            this.num_sliders = equalizer.getNumberOfBands();
            short[] bandLevelRange = this.eq.getBandLevelRange();
            this.min_level = bandLevelRange[0];
            this.max_level = bandLevelRange[1];
            int i = 0;
            while (i < this.num_sliders && i < 5) {
                int centerFreq = this.eq.getCenterFreq((short) i);
                this.sliders[i].setOnSeekBarChangeListener(this);
                this.slider_labels[i].setText(milliHzToString(centerFreq));
                i++;
            }
            for (short s = 0; s < this.eq.getNumberOfPresets(); s = (short) (s + 1)) {
                this.eqPreset.add(this.eq.getPresetName(s));
            }
            this.eqPreset.add("Custom");
            this.spinner.setAdapter((SpinnerAdapter) arrayAdapter);
        }
        initialize();
        try {
            updateUI();
            this.canEnable = true;
        } catch (Throwable th) {
            disableEvery();
            th.printStackTrace();
        }
        this.spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {

            @Override // android.widget.AdapterView.OnItemSelectedListener
            public void onNothingSelected(AdapterView<?> adapterView) {
            }

            @Override // android.widget.AdapterView.OnItemSelectedListener
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long j) {
                if (i < MainActivity.this.eqPreset.size() - 1) {
                    try {
                        MainActivity.this.eq.usePreset((short) i);
                        MainActivity.this.canPreset = true;
                        MainActivity.this.spinnerPos = i;
                        MainActivity.this.updateSliders();
                        MainActivity.this.saveChanges();
                    } catch (Throwable th) {
                        MainActivity.this.disablePreset();
                        th.printStackTrace();
                    }
                } else {
                    MainActivity.this.dontcall = true;
                    MainActivity.this.spinnerPos = i;
                    MainActivity.this.saveChanges();
                    MainActivity.this.applyChanges();
                    MainActivity.this.updateSliders();
                    MainActivity.this.dontcall = false;
                }
            }
        });
        this.virtualSlider.setOnProgressChangedListener(new ProgressListener() {

            @Override
            public void invoke(int i) {
                if (MainActivity.this.canEnable) {
                    try {
                        MainActivity.this.virtualizer.setStrength((short) i);
                    } catch (Throwable th) {
                        th.printStackTrace();
                    }
                    MainActivity.this.saveChanges();
                    return;
                }
                MainActivity.this.disableEvery();
            }
        });
        this.bassSlider.setOnProgressChangedListener(new ProgressListener() {
            @Override
            public void invoke(int i) {
                if (MainActivity.this.canEnable) {
                    try {
                        MainActivity.this.bb.setStrength((short) i);
                    } catch (Throwable th) {
                        th.printStackTrace();
                    }
                    MainActivity.this.saveChanges();
                    return;
                }
                MainActivity.this.disableEvery();
            }
        });
        this.loudSlider.setOnProgressChangedListener(new ProgressListener() {
            @Override
            public void invoke(int i) {
                if (MainActivity.this.canEnable) {
                    if (Build.VERSION.SDK_INT >= 19) {
                        try {
                            MainActivity.this.loudnessEnhancer.setTargetGain(i);
                        } catch (Throwable th) {
                            th.printStackTrace();
                        }
                    }
                    MainActivity.this.saveChanges();
                    return;
                }
                MainActivity.this.disableEvery();
            }
        });
        if (this.virtualizer != null) {
            this.enableVirtual.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                public void onCheckedChanged(CompoundButton compoundButton, boolean z) {
                    if (MainActivity.this.canEnable) {
                        if (MainActivity.this.enableVirtual.isChecked()) {
                            MainActivity.this.virtualizer.setEnabled(true);
                            MainActivity.this.virtualSlider.setEnabled(true);
                            MainActivity.this.virtualSlider.setProgressColor(ContextCompat.getColor(MainActivity.this.getBaseContext(), R.color.colorAccent));
                            MainActivity.this.saveChanges();
                        } else {
                            MainActivity.this.virtualizer.setEnabled(false);
                            MainActivity.this.virtualSlider.setEnabled(false);
                            MainActivity.this.virtualSlider.setProgressColor(ContextCompat.getColor(MainActivity.this.getBaseContext(), R.color.progress_gray));
                            MainActivity.this.saveChanges();
                        }
                        MainActivity.this.serviceChecker();
                        return;
                    }
                    MainActivity.this.disableEvery();
                }
            });
        }
        if (this.bb != null) {
            this.enableBass.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                public void onCheckedChanged(CompoundButton compoundButton, boolean z) {
                    if (MainActivity.this.canEnable) {
                        if (MainActivity.this.enableBass.isChecked()) {
                            MainActivity.this.bb.setEnabled(true);
                            MainActivity.this.bassSlider.setEnabled(true);
                            MainActivity.this.bassSlider.setProgressColor(ContextCompat.getColor(MainActivity.this.getBaseContext(), R.color.colorAccent));
                            Toast.makeText(MainActivity.this.getApplicationContext(), (int) R.string.bass_warning, Toast.LENGTH_SHORT).show();
                            MainActivity.this.saveChanges();
                        } else {

                            MainActivity.this.bb.setEnabled(false);
                            MainActivity.this.bassSlider.setEnabled(false);
                            MainActivity.this.bassSlider.setProgressColor(ContextCompat.getColor(MainActivity.this.getBaseContext(), R.color.progress_gray));
                            MainActivity.this.saveChanges();
                        }
                        MainActivity.this.serviceChecker();
                        return;
                    }
                    MainActivity.this.disableEvery();
                }
            });
        }
        if (this.loudnessEnhancer != null) {
            this.enableLoud.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                public void onCheckedChanged(CompoundButton compoundButton, boolean z) {
                    if (MainActivity.this.canEnable) {
                        if (MainActivity.this.enableLoud.isChecked()) {
                            Toast.makeText(MainActivity.this.getApplicationContext(), (int) R.string.warning, Toast.LENGTH_SHORT).show();
                            MainActivity.this.loudnessEnhancer.setEnabled(true);
                            MainActivity.this.loudSlider.setEnabled(true);
                            MainActivity.this.loudSlider.setProgressColor(ContextCompat.getColor(MainActivity.this.getBaseContext(), R.color.colorAccent));
                            MainActivity.this.saveChanges();
                        } else {
                            MainActivity.this.loudnessEnhancer.setEnabled(false);
                            MainActivity.this.loudSlider.setEnabled(false);
                            MainActivity.this.loudSlider.setProgressColor(ContextCompat.getColor(MainActivity.this.getBaseContext(), R.color.progress_gray));
                            MainActivity.this.saveChanges();
                        }
                        MainActivity.this.serviceChecker();
                        return;
                    }
                    MainActivity.this.disableEvery();
                }
            });
        }
        if (this.eq != null) {
            this.enabled.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                public void onCheckedChanged(CompoundButton compoundButton, boolean z) {
                    if (MainActivity.this.canEnable) {
                        if (MainActivity.this.enabled.isChecked()) {
                            MainActivity.this.tester.setText("Enable Equalizer ");
                            MainActivity.this.spinner.setEnabled(true);
                            MainActivity.this.eq.setEnabled(true);
                            MainActivity.this.saveChanges();

                            for (int i = 0; i < 5; i++) {
                                MainActivity.this.sliders[i].setEnabled(true);
                            }
                        } else {
                            MainActivity.this.tester.setText("Disable Equalizer");
                            MainActivity.this.spinner.setEnabled(false);
                            MainActivity.this.eq.setEnabled(false);
                            MainActivity.this.saveChanges();
                            for (int i2 = 0; i2 < 5; i2++) {
                                MainActivity.this.sliders[i2].setEnabled(false);
                            }
                        }
                        MainActivity.this.serviceChecker();
                        return;
                    }
                    MainActivity.this.disableEvery();
                }
            });
        }
    }

    public String milliHzToString(int i) {
        if (i < 1000) {
            return "";
        }
        if (i < 1000000) {
            return "" + (i / 1000) + "Hz";
        }
        return "" + (i / 1000000) + "kHz";
    }

    public void onProgressChanged(SeekBar seekBar, int i, boolean z) {
        if (this.eq != null && this.canEnable) {
            int i2 = this.min_level;
            int i3 = i2 + (((this.max_level - i2) * i) / 100);
            for (int i4 = 0; i4 < this.num_sliders; i4++) {
                if (this.sliders[i4] == seekBar) {
                    this.eq.setBandLevel((short) i4, (short) i3);
                    saveChanges();
                    return;
                }
            }
        }
    }

    public void onStartTrackingTouch(SeekBar seekBar) {
        this.spinner.setSelection(this.eqPreset.size() - 1);
        this.spinnerPos = this.eqPreset.size() - 1;
    }

    public void updateUI() {
        applyChanges();
        serviceChecker();
        if (this.enableBass.isChecked()) {
            this.bassSlider.setEnabled(true);
            this.bassSlider.setProgressColor(ContextCompat.getColor(getBaseContext(), R.color.colorAccent));
            this.bb.setEnabled(true);
        } else {
            this.bassSlider.setEnabled(false);
            this.bassSlider.setProgressColor(ContextCompat.getColor(getBaseContext(), R.color.progress_gray));
            this.bb.setEnabled(false);
        }
        if (this.enableVirtual.isChecked()) {
            this.virtualizer.setEnabled(true);
            this.virtualSlider.setProgressColor(ContextCompat.getColor(getBaseContext(), R.color.colorAccent));
            this.virtualSlider.setEnabled(true);
        } else {
            this.virtualizer.setEnabled(false);
            this.virtualSlider.setEnabled(false);
            this.virtualSlider.setProgressColor(ContextCompat.getColor(getBaseContext(), R.color.progress_gray));
        }
        if (this.enableLoud.isChecked()) {
            this.loudnessEnhancer.setEnabled(true);
            this.loudSlider.setProgressColor(ContextCompat.getColor(getBaseContext(), R.color.colorAccent));
            this.loudSlider.setEnabled(true);
        } else {
            this.loudnessEnhancer.setEnabled(false);
            this.loudSlider.setEnabled(false);
            this.loudSlider.setProgressColor(ContextCompat.getColor(getBaseContext(), R.color.progress_gray));
        }
        if (this.enabled.isChecked()) {
            this.spinner.setEnabled(true);
            for (int i = 0; i < 5; i++) {
                this.sliders[i].setEnabled(true);
            }
            this.eq.setEnabled(true);
        } else {
            this.spinner.setEnabled(false);
            for (int i2 = 0; i2 < 5; i2++) {
                this.sliders[i2].setEnabled(false);
            }
            this.eq.setEnabled(false);
        }
        this.spinner.setSelection(this.spinnerPos);
        updateSliders();
        updateBassBoost();
        updateVirtualizer();
        updateLoudness();
    }

    public void updateSliders() {
        for (int i = 0; i < this.num_sliders; i++) {
            Equalizer equalizer = this.eq;
            this.sliders[i].setProgress((((equalizer != null ? equalizer.getBandLevel((short) i) : 0) * 100) / (this.max_level - this.min_level)) + 50);
        }
    }

    public void updateBassBoost() {
        BassBoost bassBoost = this.bb;
        if (bassBoost != null) {
            this.bassSlider.setProgress(bassBoost.getRoundedStrength());
        } else {
            this.bassSlider.setProgress(0);
        }
    }

    public void updateVirtualizer() {
        Virtualizer virtualizer2 = this.virtualizer;
        if (virtualizer2 != null) {
            this.virtualSlider.setProgress(virtualizer2.getRoundedStrength());
        } else {
            this.virtualSlider.setProgress(0);
        }
    }

    public void updateLoudness() {
        if (this.loudnessEnhancer == null) {
            this.loudSlider.setProgress(0);
        } else if (Build.VERSION.SDK_INT >= 19) {
            try {
                this.loudSlider.setProgress((int) this.loudnessEnhancer.getTargetGain());
            } catch (Throwable th) {
                th.printStackTrace();
            }
        }
    }

    public void saveChanges() {
        SharedPreferences.Editor edit = PreferenceManager.getDefaultSharedPreferences(this).edit();
        edit.putBoolean("initial", true);
        edit.putBoolean("eqswitch", this.enabled.isChecked());
        edit.putBoolean("bbswitch", this.enableBass.isChecked());
        edit.putBoolean("virswitch", this.enableVirtual.isChecked());
        edit.putBoolean("loudswitch", this.enableLoud.isChecked());
        edit.putInt("spinnerpos", this.spinnerPos);
        try {
            if (this.bb != null) {
                edit.putInt("bbslider", this.bb.getRoundedStrength());
            } else {
                BassBoost bassBoost = new BassBoost(100, 0);
                this.bb = bassBoost;
                edit.putInt("bbslider", bassBoost.getRoundedStrength());
            }
            if (this.virtualizer != null) {
                edit.putInt("virslider", this.virtualizer.getRoundedStrength());
            } else {
                Virtualizer virtualizer2 = new Virtualizer(100, 0);
                this.virtualizer = virtualizer2;
                edit.putInt("virslider", virtualizer2.getRoundedStrength());
            }
            if (this.loudnessEnhancer != null) {
                if (Build.VERSION.SDK_INT >= 19) {
                    edit.putFloat("loudslider", this.loudnessEnhancer.getTargetGain());
                }
            } else if (Build.VERSION.SDK_INT >= 19) {
                LoudnessEnhancer loudnessEnhancer2 = new LoudnessEnhancer(0);
                this.loudnessEnhancer = loudnessEnhancer2;
                edit.putFloat("loudslider", loudnessEnhancer2.getTargetGain());
            }
        } catch (Throwable th) {
            edit.putInt("bbslider", 0);
            edit.putInt("virslider", 0);
            edit.putFloat("loudslider", 0.0f);
            th.printStackTrace();
        }
        if (this.spinnerPos == this.eqPreset.size() - 1 && !this.dontcall) {
            edit.putInt("slider0", ((this.eq.getBandLevel((short) 0) * 100) / (this.max_level - this.min_level)) + 50);
            edit.putInt("slider1", ((this.eq.getBandLevel((short) 1) * 100) / (this.max_level - this.min_level)) + 50);
            edit.putInt("slider2", ((this.eq.getBandLevel((short) 2) * 100) / (this.max_level - this.min_level)) + 50);
            edit.putInt("slider3", ((this.eq.getBandLevel((short) 3) * 100) / (this.max_level - this.min_level)) + 50);
            edit.putInt("slider4", ((this.eq.getBandLevel((short) 4) * 100) / (this.max_level - this.min_level)) + 50);
        }
        edit.apply();
    }

    public void applyChanges() {
        SharedPreferences defaultSharedPreferences = PreferenceManager.getDefaultSharedPreferences(this);
        this.spinnerPos = defaultSharedPreferences.getInt("spinnerpos", 0);
        this.enabled.setChecked(defaultSharedPreferences.getBoolean("eqswitch", true));
        this.enableBass.setChecked(defaultSharedPreferences.getBoolean("bbswitch", true));
        this.enableVirtual.setChecked(defaultSharedPreferences.getBoolean("virswitch", true));
        this.enableLoud.setChecked(defaultSharedPreferences.getBoolean("loudswitch", false));
        try {
            if (this.bb != null) {
                try {
                    this.bb.setStrength((short) defaultSharedPreferences.getInt("bbslider", 0));
                } catch (Throwable th) {
                    th.printStackTrace();
                }
            } else {
                BassBoost bassBoost = new BassBoost(100, 0);
                this.bb = bassBoost;
                try {
                    bassBoost.setStrength((short) defaultSharedPreferences.getInt("bbslider", 0));
                } catch (Throwable th2) {
                    th2.printStackTrace();
                }
            }
            if (this.virtualizer != null) {
                try {
                    this.virtualizer.setStrength((short) defaultSharedPreferences.getInt("virslider", 0));
                } catch (Throwable th3) {
                    th3.printStackTrace();
                }
            } else {
                Virtualizer virtualizer2 = new Virtualizer(100, 0);
                this.virtualizer = virtualizer2;
                try {
                    virtualizer2.setStrength((short) defaultSharedPreferences.getInt("virslider", 0));
                } catch (Throwable th4) {
                    th4.printStackTrace();
                }
            }
            if (this.loudnessEnhancer != null) {
                if (Build.VERSION.SDK_INT >= 19) {
                    try {
                        this.loudnessEnhancer.setTargetGain((int) defaultSharedPreferences.getFloat("loudslider", 0.0f));
                    } catch (Throwable th5) {
                        th5.printStackTrace();
                    }
                }
            } else if (Build.VERSION.SDK_INT >= 19) {
                LoudnessEnhancer loudnessEnhancer2 = new LoudnessEnhancer(0);
                this.loudnessEnhancer = loudnessEnhancer2;
                try {
                    loudnessEnhancer2.setTargetGain((int) defaultSharedPreferences.getFloat("loudslider", 0.0f));
                } catch (Throwable th6) {
                    th6.printStackTrace();
                }
            }
        } catch (Throwable th7) {
            th7.printStackTrace();
        }
        if (this.spinnerPos != this.eqPreset.size() - 1) {
            try {
                this.eq.usePreset((short) this.spinnerPos);
            } catch (Throwable th8) {
                disablePreset();
                th8.printStackTrace();
            }
        } else {
            Equalizer equalizer = this.eq;
            int i = this.min_level;
            equalizer.setBandLevel((short) 0, (short) (i + (((this.max_level - i) * defaultSharedPreferences.getInt("slider0", 0)) / 100)));
            Equalizer equalizer2 = this.eq;
            int i2 = this.min_level;
            equalizer2.setBandLevel((short) 1, (short) (i2 + (((this.max_level - i2) * defaultSharedPreferences.getInt("slider1", 0)) / 100)));
            Equalizer equalizer3 = this.eq;
            int i3 = this.min_level;
            equalizer3.setBandLevel((short) 2, (short) (i3 + (((this.max_level - i3) * defaultSharedPreferences.getInt("slider2", 0)) / 100)));
            Equalizer equalizer4 = this.eq;
            int i4 = this.min_level;
            equalizer4.setBandLevel((short) 3, (short) (i4 + (((this.max_level - i4) * defaultSharedPreferences.getInt("slider3", 0)) / 100)));
            Equalizer equalizer5 = this.eq;
            int i5 = this.min_level;
            equalizer5.setBandLevel((short) 4, (short) (i5 + (((this.max_level - i5) * defaultSharedPreferences.getInt("slider4", 0)) / 100)));
        }
    }

    public void disableEvery() {
        Toast.makeText(this, (int) R.string.disableOther, Toast.LENGTH_SHORT).show();
        this.spinner.setEnabled(false);
        this.enabled.setChecked(false);
        this.enableVirtual.setChecked(false);
        this.enableBass.setChecked(false);
        this.enableLoud.setChecked(false);
        this.canEnable = false;
        if (Build.VERSION.SDK_INT >= 19) {
            this.loudnessEnhancer.setEnabled(false);
        }
        this.loudSlider.setEnabled(false);
        this.loudSlider.setProgressColor(ContextCompat.getColor(getBaseContext(), R.color.progress_gray));
        this.virtualizer.setEnabled(false);
        this.virtualSlider.setEnabled(false);
        this.virtualSlider.setProgressColor(ContextCompat.getColor(getBaseContext(), R.color.progress_gray));
        this.bassSlider.setEnabled(false);
        this.bassSlider.setProgressColor(ContextCompat.getColor(getBaseContext(), R.color.progress_gray));
        this.bb.setEnabled(false);
        for (int i = 0; i < 5; i++) {
            this.sliders[i].setEnabled(false);
        }
        this.eq.setEnabled(false);
    }

    public void disablePreset() {
        this.presetView.setVisibility(View.GONE);
        this.canPreset = false;
    }

    public void initialize() {
        SharedPreferences defaultSharedPreferences = PreferenceManager.getDefaultSharedPreferences(this);
        SharedPreferences.Editor edit = defaultSharedPreferences.edit();
        if (!defaultSharedPreferences.contains("initial")) {
            edit.putBoolean("initial", true);
            edit.putBoolean("eqswitch", false);
            edit.putBoolean("bbswitch", false);
            edit.putBoolean("virswitch", false);
            edit.putInt("bbslider", this.bb.getRoundedStrength());
            edit.putBoolean("loudswitch", false);
            if (Build.VERSION.SDK_INT >= 19) {
                edit.putFloat("loudslider", this.loudnessEnhancer.getTargetGain());
            }
            edit.putInt("virslider", this.virtualizer.getRoundedStrength());
            edit.putInt("slider0", ((this.eq.getBandLevel((short) 0) * 100) / (this.max_level - this.min_level)) + 50);
            edit.putInt("slider1", ((this.eq.getBandLevel((short) 1) * 100) / (this.max_level - this.min_level)) + 50);
            edit.putInt("slider2", ((this.eq.getBandLevel((short) 2) * 100) / (this.max_level - this.min_level)) + 50);
            edit.putInt("slider3", ((this.eq.getBandLevel((short) 3) * 100) / (this.max_level - this.min_level)) + 50);
            edit.putInt("slider4", ((this.eq.getBandLevel((short) 4) * 100) / (this.max_level - this.min_level)) + 50);
            edit.putInt("spinnerpos", 0);
            edit.apply();
        }
    }

    public void serviceChecker() {
        if (this.enabled.isChecked() || this.enableBass.isChecked() || this.enableVirtual.isChecked() || this.enableLoud.isChecked()) {
            Intent intent = new Intent(this, ForegroundService.class);
            intent.setAction(Constants.ACTION.STARTFOREGROUND_ACTION);
            startService(intent);
            return;
        }
        Intent intent2 = new Intent(this, ForegroundService.class);
        intent2.setAction(Constants.ACTION.STOPFOREGROUND_ACTION);
        startService(intent2);
    }
}
