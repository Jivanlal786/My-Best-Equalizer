package com.bcdstudio.soundarea;

public class Constants {

    public interface ACTION {
        public static final String MAIN_ACTION = "com.bcdstudio.soundarea.action.main";
        public static final String STARTFOREGROUND_ACTION = "com.bcdstudio.foregroundservice.action.startforeground";
        public static final String STOPFOREGROUND_ACTION = "com.bcdstudio.foregroundservice.action.stopforeground";
    }

    public interface NOTIFICATION_ID {
        public static final int FOREGROUND_SERVICE = 101;
    }
}
