package com.bcdstudio.soundarea;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;

import androidx.appcompat.app.AppCompatActivity;

import com.example.myequalizer.R;

public class SplashScreen extends AppCompatActivity {
    final int SPLASH_TIME_OUT = 3000;

    @Override
    public void onCreate(Bundle bundle) {
        requestWindowFeature(1);
        getWindow().setFlags(1024, 1024);
        super.onCreate(bundle);
        setContentView(R.layout.activity_splash);
        new Handler().postDelayed(new Runnable() {
            public void run() {
                SplashScreen.this.startActivity(new Intent(SplashScreen.this, MainActivity.class));
                SplashScreen.this.overridePendingTransition(0, 0);
                SplashScreen.this.finish();
            }
        }, 3000);
    }
}
