package com.bcdstudio.soundarea;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.os.Build;
import android.os.IBinder;
import android.util.Log;
import androidx.core.app.NotificationCompat;
import com.bcdstudio.soundarea.Constants;
import com.example.myequalizer.R;

public class ForegroundService extends Service {
    private static final String LOG_TAG = "ForegroundService";
    String CHANNEL_ID = "myChannel";

    public IBinder onBind(Intent intent) {
        return null;
    }

    public void onCreate() {
        super.onCreate();
        createNotificationChannel();
    }

    public int onStartCommand(Intent intent, int i, int i2) {
        if (intent.getAction().equals(Constants.ACTION.STARTFOREGROUND_ACTION)) {
            Log.i(LOG_TAG, "Received Start Foreground Intent ");
            Intent intent2 = new Intent(this, MainActivity.class);
            intent2.setAction(Constants.ACTION.MAIN_ACTION);
//            intent2.setFlags(268468224);
            intent2.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startForeground(101, new NotificationCompat.Builder(this, this.CHANNEL_ID).setSmallIcon(R.drawable.eq_icon).setContentTitle("Equalizer").setContentText("Sound power adjusted").setSound(null).setContentIntent(PendingIntent.getActivity(this, 0, intent2, 0)).setPriority(1).setOngoing(true).build());
            Log.i("WOW", "BUILDED NOTIFICATION ");
            return START_REDELIVER_INTENT;
        } else if (!intent.getAction().equals(Constants.ACTION.STOPFOREGROUND_ACTION)) {
            return START_REDELIVER_INTENT;
        } else {
            Log.i(LOG_TAG, "Received Stop Foreground Intent");
            stopForeground(true);
            stopSelf();
            return START_REDELIVER_INTENT;
        }
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel notificationChannel = new NotificationChannel(this.CHANNEL_ID, "Equalizer", NotificationManager.IMPORTANCE_DEFAULT);
            notificationChannel.setDescription("Equalizer is enabled");
            notificationChannel.setSound(null, null);
            ((NotificationManager) getSystemService(NotificationManager.class)).createNotificationChannel(notificationChannel);
        }
    }

    public void onDestroy() {
        super.onDestroy();
        Log.i(LOG_TAG, "In onDestroy");
    }
}
